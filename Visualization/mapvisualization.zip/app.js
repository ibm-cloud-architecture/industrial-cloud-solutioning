
/**
 * Module dependencies.
 */

var express = require('express')
  , routes = require('./routes')
  , user = require('./routes/user')
  , http = require('http'),
  path = require('path'),
  Client=require('node-rest-client').Client,
  Cloudant = require('cloudant'),
  request = require('request'),
  helmet = require('helmet')
;

var db2;
var hasConnect = false;


var app = express();

// all environments
app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(app.router);
app.use(express.static(path.join(__dirname, 'public')));

//var cfenv = require('cfenv');

// development only
if ('development' === app.get('env')) {
  app.use(express.errorHandler());
}

if (process.env.VCAP_SERVICES) {
    var env = JSON.parse(process.env.VCAP_SERVICES);
	if (env['dashDB']) {
        hasConnect = true;
		db2 = env['dashDB'][0].credentials;
	}
	
}

if ( hasConnect === false ) {

	   db2 = {
	        db: "BLUDB",
	        hostname: "yp-dashdb-small-01-lon02.services.eu-gb.bluemix.net",
	        port: 50000,
	        username: "dash108157",
	        password: "62PRatC5CInN"
	     };
	}

var connString = "DRIVER={DB2};DATABASE=" + db2.db + ";UID=" + db2.username + ";PWD=" + db2.password + ";HOSTNAME=" + db2.hostname + ";port=" + db2.port;

//app.get('/', routes.index);

app.get('/',function(req,res){
	res.sendfile(path.join(__dirname, 'public')+'/assets.html');
});


app.get('/users', user.list);


/*Fetch Records from Database and publish against context menu events of Map*/
app.get('/ws/custrec',function(req,res,next){
	var me =process.env.username;
	var password = process.env.password;
	var options_auth = { user: "dafc8da0-0306-4ac4-bff1-30d182da8dda-bluemix", password: "77d29546fc84dc809931977e071df9f1e0b32ef651e54caa832a6289f5e950d3" };
	var client = new Client(options_auth);	
	var mapdata="[";
	client.get("https://dafc8da0-0306-4ac4-bff1-30d182da8dda-bluemix.cloudant.com/customerdb/_design/customerdd/_view/customer?limit=20&reduce=false&include_docs=true&conflicts=true", function (data, response) {
		// parsed response body as js object 
	    console.log('***********************');
	    console.log(data);
	    var obj=JSON.parse(JSON.stringify(data));
	    var datalength=obj.rows.length;
	    console.log("datalength:: " +datalength);		
	    console.log(JSON.stringify(obj.rows[0].doc.Name)+":" +JSON.stringify(obj.rows[1].doc.Name) );
	    for(var i=0;i<datalength;i++){
	    	console.log("inside loop:: " +i);
	    	mapdata+="{\"Name\":"+JSON.stringify(obj.rows[i].doc.Name)+",\"Age:\":"+JSON.stringify(obj.rows[i].doc.Age)+",\"Country:\":"+JSON.stringify(obj.rows[i].doc.Country)+",\"Address:\":"+JSON.stringify(obj.rows[i].doc.Address)+",\"Married:\":"+JSON.stringify(obj.rows[i].doc.Married)+"}";
	    	if(i!==datalength-1){mapdata+=",";}
	    }
	    mapdata+="]";
		 var jsonObj=JSON.parse(mapdata);
		 console.log(mapdata);
		 var response="{\"total\":"+datalength+",\"rows\":"+JSON.stringify(jsonObj)+"}";
		 console.log(response);
		 //res.end(JSON.stringify({"data" :response}));
		  res.end(JSON.stringify({"rows" :jsonObj}));
	});

});


app.get('/ws/test',function(req,res,next){
	var me =process.env.username;
	var password = process.env.password;
   // var mapdata="\"doc\": [";
    var mapdata="[";
    var obj;
	var options_auth = { user: "dafc8da0-0306-4ac4-bff1-30d182da8dda-bluemix", password: "77d29546fc84dc809931977e071df9f1e0b32ef651e54caa832a6289f5e950d3" };
	var client = new Client(options_auth);
	//client.get("https://dafc8da0-0306-4ac4-bff1-30d182da8dda-bluemix:77d29546fc84dc809931977e071df9f1e0b32ef651e54caa832a6289f5e950d3@dafc8da0-0306-4ac4-bff1-30d182da8dda-bluemix.cloudant.com/crimes/_design/geodd/_geo/geoidx?bbox=-180%2C-90%2C180%2C90&limit=20&relation=contains", function (data, response) {
	client.get("https://dafc8da0-0306-4ac4-bff1-30d182da8dda-bluemix.cloudant.com/crimes/_design/geodd/_geo/geoidx?bbox=-180%2C-90%2C180%2C90&limit=20&relation=contains&include_docs=true", function (data, response) {
	// parsed response body as js object 
	    console.log(data);
	    console.log('***********************');
	    var obj=JSON.parse(JSON.stringify(data));
	    var datalength=obj.rows.length;
	    console.log("datalength:: " +datalength);
	    for(var i=0;i<datalength;i++){
	    	    mapdata+="{\"geometry\":"+JSON.stringify(obj.rows[i].doc.geometry)+",\"properties\":"+JSON.stringify(obj.rows[i].doc.properties)+",\"type\":"+JSON.stringify(obj.rows[i].doc.type)+"}";
	    	    if(i!==datalength-1){mapdata+=",";}
	    }
	    mapdata+="]";
	    // raw response 
	    //console.log(response);
	    var jsonObj=JSON.parse(mapdata);
	    console.log(mapdata);
	    res.end(JSON.stringify({"data" :jsonObj}));
	});
});

app.get('/ws/assets',function(req,res,next){
	var me =process.env.username;
	var password = process.env.password;
   // var mapdata="\"doc\": [";
    var mapdata="[";
    var obj;
	var options_auth = { user: "dafc8da0-0306-4ac4-bff1-30d182da8dda-bluemix", password: "77d29546fc84dc809931977e071df9f1e0b32ef651e54caa832a6289f5e950d3" };
	var client = new Client(options_auth);
	//client.get("https://dafc8da0-0306-4ac4-bff1-30d182da8dda-bluemix:77d29546fc84dc809931977e071df9f1e0b32ef651e54caa832a6289f5e950d3@dafc8da0-0306-4ac4-bff1-30d182da8dda-bluemix.cloudant.com/crimes/_design/geodd/_geo/geoidx?bbox=-180%2C-90%2C180%2C90&limit=20&relation=contains", function (data, response) {
	client.get("https://dafc8da0-0306-4ac4-bff1-30d182da8dda-bluemix.cloudant.com/warehousedb/_design/geodd/_geo/geoidx?bbox=-180%2C-90%2C180%2C90&limit=20&relation=contains&include_docs=true", function (data, response) {
	// parsed response body as js object 
	    console.log(data);
	    console.log('***********************');
	    var obj=JSON.parse(JSON.stringify(data));
	    var datalength=obj.rows.length;
	    console.log("datalength:: " +datalength);
	    for(var i=0;i<datalength;i++){
	    	    mapdata+="{\"geometry\":"+JSON.stringify(obj.rows[i].doc.geometry)+",\"properties\":"+JSON.stringify(obj.rows[i].doc.properties)+",\"type\":"+JSON.stringify(obj.rows[i].doc.type)+"}";
	    	    if(i!==datalength-1){mapdata+=",";}
	    }
	    mapdata+="]";
	    // raw response 
	    //console.log(response);
	    var jsonObj=JSON.parse(mapdata);
	    console.log(mapdata);
	    res.end(JSON.stringify({"data" :jsonObj}));
	});
});

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
