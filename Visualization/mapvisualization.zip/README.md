Note: Before running code please make sure of Internet connectivity on the machine and NodeJS installed
--------------------------------------------------------------------------------------------------------

# weatherapptest



## Usage



## Developing
 


### Tools
a) Install Eclipse eclipse-jee-kepler-SR2-win32-x86_64
b) Install Nodeclipse-1.0.2 from eclipse marketplace
c) Create a Node.js express project.
d) bring in the code into it.
e) Goto project root and run command - npm install
e) Rt. click on app.js and select RunAS -> Node Application.
   One should see the message in eclipse console that app is listening to port 3000.
f) Open browser and type http://localhost:3000/assets.html


Commandline
------------
a) Install Node JS runtime
b) npm install 
c) node app.js

Installing on Bluemix
------------------------
a) Install Bluemix commandline
b) Install cf commandline
c) Create a NodeJS SDK runtime on bluemix.
d) Download started app and copy manifest.yml into the root folder
e) Goto root folder of the project and type the following command:
         bluemix cf push
f) Click on startapp.


Created with [Nodeclipse](https://github.com/Nodeclipse/nodeclipse-1)
 ([Eclipse Marketplace](http://marketplace.eclipse.org/content/nodeclipse), [site](http://www.nodeclipse.org))   

Nodeclipse is free open-source project that grows with your contributions.
